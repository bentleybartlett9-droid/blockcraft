BLOCKCRAFT CAVES / EXPLORATION / ANIMAL SOUNDS UPDATE

Upload BOTH files to the ROOT of your GitHub repo:
1. exploration-update.js  (new file)
2. index.html             (replace the current index.html)

Leave blockcraft-vr.html exactly as it is.

What this update adds:
- larger connected cave tunnels
- large cave chambers
- rare underground ruins with a chest
- cave mushrooms
- glowing cave pockets and crystal/diamond decoration
- subtle cave ambience
- discovery messages while exploring underground
- finished unique sounds for Mossling, Moonhopper and Crystalback
- Crystalbacks can spawn underground
- keeps the current armour, sprint, flight, animals, woods and biome work intact

Important:
The new cave generation affects newly generated/unexplored chunks. Existing saved chunks are intentionally not rewritten.
